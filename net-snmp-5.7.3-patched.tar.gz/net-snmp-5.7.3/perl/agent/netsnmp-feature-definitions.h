#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-features.h>

netsnmp_feature_require(agent_check_and_process)
netsnmp_feature_require(snmp_enable_stderrlog)

